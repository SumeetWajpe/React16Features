import {posts} from './postsreducer';
import {users} from './userreducer';
import {combineReducers} from 'redux';

export var rootReducer = combineReducers({
    users,
    posts
});

 
