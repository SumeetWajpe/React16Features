import React from 'react';


export class MainComponent extends React.Component{
    
    componentDidMount(){
        this.props.LoadUsers();// dispatch an action !
    }
    render(){

          return <div className="container">
           <div className="jumbotron">
                    <h1> Github users </h1>
           </div>
            {React.cloneElement(this.props.children,this.props)}
            </div>
    }
}