import {connect} from 'react-redux';
import * as allactions from '../actions/actions';
import {bindActionCreators} from 'redux';
import { MainComponent } from './main.component';

function mapStateToProps(store){
        return {
            allusers:store.users,
            allposts:store.posts
        }
}

function mapDispatchToProps(dispatcher){
        return bindActionCreators(allactions,dispatcher)
}

export var app = connect(mapStateToProps,mapDispatchToProps)(MainComponent);
