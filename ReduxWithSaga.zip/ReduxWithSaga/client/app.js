// Code Here

import { MainComponent } from './components/main.component';
import { UsersComponent } from './components/users.component';
import { UserDetails } from './components/userdetails.component';
import store from './store/store';
import {app} from './components/connect';

import React from 'react';
import ReactDOM from 'react-dom';
import {Router,Route,IndexRoute,browserHistory} from 'react-router';
import {Provider} from 'react-redux';

var router = <Provider store={store}>
                        <Router history={browserHistory}>
                        <Route path="/" component={app}>
                                  <IndexRoute component={UsersComponent}></IndexRoute>
                                <Route path="/userdetails/:id" component={UserDetails}></Route>
                        </Route>
                     </Router>
                    </Provider> 

ReactDOM.render(router,document.getElementById('content'))

