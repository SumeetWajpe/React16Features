import "regenerator-runtime/runtime"; // load 
import {createStore,applyMiddleware} from 'redux';
import {rootReducer} from '../reducers/rootReducer';
import createSagaMiddleware from 'redux-saga';
import users from '../data/data';
import { watchgetUsers } from '../saga/saga';
// var storeData = {
//     users:users,
//     posts:[{id:1,name:'article'}]
// }

const sagaMiddleware = createSagaMiddleware();
var store = createStore(rootReducer,
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
    ,applyMiddleware(sagaMiddleware));
sagaMiddleware.run(watchgetUsers);
export default store;