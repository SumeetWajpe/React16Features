import React from "react";
import { LikesContext } from "./App";
import Product from "./product.component";

class ListOfProducts extends React.Component {
  render() {
    // let productsToBeCreated = this.props.allProducts.map((p) => (
    //   <Product productdetails={p} key={p.id} {...this.props} />
    // ));
    return (
      <LikesContext.Consumer>
        {(context) => (
          <React.Fragment>
            <div className="jumbotron">
              <h1>Online Shopping</h1>
            </div>
            <div className="row">
              {context.allProducts.map((p) => (
                <Product productdetails={p} key={p.id} {...this.props} />
              ))}
            </div>
          </React.Fragment>
        )}
      </LikesContext.Consumer>
    );
    // babel JS converts JSX to React API !
  }
}

export default ListOfProducts;
