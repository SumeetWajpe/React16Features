import React, { useEffect,useState } from 'react';
import axios from 'axios';

export const PostDetails = (props) => {
    
    const {match:{params}} = props; 
    var singlepost = props.allPosts.find(p=>p.id == params.id);
    return(
        <div>
            <div className="jumbotron">
                <h1>Post Details for {params.id} </h1>                
            </div>
            <h3>Id : {singlepost.id}</h3>
            <h3>User Id : {singlepost.userId}</h3>
            <h3>Title : {singlepost.title}</h3>
            <h3>Body : {singlepost.body}</h3>

        </div>
    )
}

export default PostDetails;